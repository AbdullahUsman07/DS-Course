#include<iostream>
#include<string>
#include<fstream>

// if the arguument is an integer then it will not throw exception hence we return false at last
bool is_valid(const std::string& file)
{
	try {
		int temp = std::stoi(file);
	}
	catch (std::invalid_argument& e)
	{
		// it will through an exception because the file name is string
		std::cout << "File directory is valid!" << std::endl;
		return true;
	}

	// this indicates it is not a file name but an integer
	return false;
}

int main(int argc, char* argv[])
{

	if (argc == 1)
	{
		std::cout << "No Input File is Given!";
	}


	for (int i = 1; i < argc; i++) {

		std::string file_path;
		file_path = argv[i];
		if (is_valid(file_path)) {

			std::fstream file_(file_path, std::ios::in);

			if (!file_.is_open())
			{
				std::cout << file_path << "   " << " cannot open this file!\n";
				// this will skip this iteration and move to next one
				continue;
			}
			std::string file_content;
			while (getline(file_, file_content))
			{
				std::cout << file_content << std::endl;
			}


			std::cout << "\n\n";
		}
		else
			std::cout << std::stoi(argv[i]) << " is not an File!\n";
		//thus we move further
	}

	return 0;
}
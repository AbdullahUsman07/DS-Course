//#include<iostream>
//#include<string>
//#include<fstream>
//
//
//// Task No 1
//int main(int argc, char* argv[])
//{
//
//
//	if (argc == 1)
//	{
//		std::cout << " No input is given" << std::endl;
//		return 0;
//	}
//
//	for (int i = 1; i < argc; i++)
//	{
//		std::cout << argv[i] << std::endl;
//	}
//
//	int result = 0;
//
//	for (int i = 1; i < argc; i++)
//	{
//		try {
//			result += std::stoi(argv[i]);
//		}
//		catch (std::invalid_argument & error)
//		{
//			std::cout << " Kindly Input only integer values!\n";
//			std::cout << argv[i] << " is not included in sum!\n";
//		}
//	}
//	
//	std::cout << "Result is: " << result << std::endl;
//	
//
//	return 0;
//}
//
//

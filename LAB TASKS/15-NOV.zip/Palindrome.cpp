#include<iostream>
#include<stack>
#include<queue>
#include<string>

bool isPalindrome(const std::string& str)
{
	int len = str.length();
	if (len %2 ==0)
	{
		return false;
	}

	std::stack<char> stk;
	std::queue<char> que;

	for (int i = 0; i < len; i++)
	{
		stk.push(str[i]);
		que.push(str[i]);
	}

	// now compare the elements
	 int i = 0;
	while(i<stk.size())
	{
		if (stk.top() != que.front())
		{
			return false;
		}
		i++;
		stk.pop();
		que.pop();
	}

	return true;
}

int main(int argc, char* argv[])
{

	/*std::string input;
	std::cout << " Input String: ";
	std::getline(std::cin, input);*/

	for (int i = 1; i <argc; i++) {

		std::string str = argv[i];
		if (isPalindrome(str))
		{
			std::cout << "Yes! "<<str <<" is a Palindrome!\n";
		}
		else
		{
			std::cout << "No " << str << " is a Palindrome!\n";
		}

	}

}
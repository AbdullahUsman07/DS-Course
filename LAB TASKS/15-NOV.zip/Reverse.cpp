//#include<iostream>
//#include<string>
//#include<queue>
//#include<stack>
//
//template<typename T>
//void reverse(std::queue<T> &que)
//{
//	if (que.empty())
//	{
//		return;
//	}
//	std::stack<T> stk;
//
//	
//	int size = que.size();
//	for (int i = 0; i <size; i++)
//	{
//		T ele = que.front();
//		stk.push(ele);
//		que.pop();
//	}
//	
//	for (int i = 0; i < size; i++)
//	{
//		T ele = stk.top();
//		stk.pop();
//		que.push(ele);
//	}
//}
//
//int main()
//{
//	
//	std::string input;
//	std::cout << " Kindly input: ";
//	std::getline(std::cin, input);
//	std::queue<char> que;
//	for (int i = 0; i < input.length(); i++)
//	{
//		que.push(input[i]);
//	}
//
//	
//	
//	reverse(que);
//	int size = que.size();
//	for (int i = 0; i <size ; i++)
//	{
//		std::cout << que.front() << "";
//		que.pop();
//	}
//	
//}
